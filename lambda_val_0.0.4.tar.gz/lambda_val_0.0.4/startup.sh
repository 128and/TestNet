account=$1
password=$2

if [ $# != 2 ]
then
    echo 'Input parameters illegal.You should provide account and password.'
    exit 1
fi

command=`ps -ef|grep './lambda run'|sed -e "/grep/d"`
if [  "$command" == "" ]
then
    echo "Try to start lambda node..."
    echo $password | nohup ./lambda run $account >> ./lambda.log 2>&1 & echo $! > ./lambda.pid
    echo "Start lambda node successfully"
else
    echo "Lambda node is already started, can't run again"
fi
