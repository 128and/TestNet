echo "Try to stop lambda node..."

pid=`cat lambda.pid`
if [ "$pid" != "" ]
then
    if [ "`ps -ef|grep './lambda run'|sed -e "/grep/d"`" == "" ]
    then
        echo "Lambda node service is not running"
    else
        kill -2 `cat lambda.pid`
        : > lambda.pid
        echo "Stop lambda node successfully"
    fi
else
    if [ "$`ps -ef|grep './lambda run'|sed -e "/grep/d"`" == "" ]
    then
        echo "Lambda node service is not running"
    else
        pkill -2 lambda
        echo "Stop lambda node successfully"
    fi
fi
